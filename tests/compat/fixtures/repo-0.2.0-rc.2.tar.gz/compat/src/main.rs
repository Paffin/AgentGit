mod util;

fn main() {
    let name = "bob";
    println!("hello, {name}");
    println!("{}", util::shout("finished"));
}
