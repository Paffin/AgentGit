pub fn shout(s: &str) -> String {
    s.to_uppercase()
}

pub fn whisper(s: &str) -> String {
    s.to_lowercase()
}

pub fn trim(s: &str) -> &str {
    s.trim()
}
